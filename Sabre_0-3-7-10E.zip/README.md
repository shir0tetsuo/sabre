# Project Sabre
### Overview
Project Sabre is a Discord bot created upon the Discord.js wrappers for NodeJS.
*The Trello for this project is mentioned in the Issues page.*
### Supported Servers
Sabre is a bot exclusively for the following Discord servers: DAVNET, State of Alaska.
### Gamma Emerald
Project Gamma Emerald is another Discord bot which all security related commands will soon
be exclusively supported by. It will be heavily dependent on the Bourne Again Shell.
### Other
If you download this and try running it, don't come crying to me if it doesn't work. This bot is a work in progress and requires the discord.js library, and NodeJS 8+, as mentioned on the official discord.js website. It's also a work-in-progress, which means bugs, bugs, bugs.
