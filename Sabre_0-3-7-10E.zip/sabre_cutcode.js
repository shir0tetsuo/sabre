/*  sql.get(`SELECT * FROM scores WHERE userId ="${message.author.id}"`).then(row => {
    if (!row) {
      sql.run("INSERT INTO scores (userId, points, level) VALUES (?, ?, ?)", [message.author.id, 1, 0]);
    } else {
      let curLevel = Math.floor(0.1 * Math.sqrt(row.points + 1));
      if (curLevel > row.level) {
        row.level = curLevel;
        sql.run(`UPDATE scores SET points = ${row.points + 1}, level = ${row.level} WHERE userId = ${message.author.id}`);
        message.reply(`You've leveled up to level **${curLevel}**! Ain't that dandy?`);
      }
      sql.run(`UPDATE scores SET points = ${row.points + 1} WHERE userId = ${message.author.id}`);
    }
  }).catch(() => {
    console.error;
    sql.run("CREATE TABLE IF NOT EXISTS scores (userId TEXT, points INTEGER, level INTEGER)").then(() => {
      sql.run("INSERT INTO scores (userId, points, level) VALUES (?, ?, ?)", [message.author.id, 1, 0]);
    });
  }); */
/*
  if (!message.content.startsWith(prefix)) return;
*/ /*
  if (message.content.startsWith(prefix + "level")) {
    sql.get(`SELECT * FROM scores WHERE userId ="${message.author.id}"`).then(row => {
      if (!row) return message.reply("Your current level is 0");
      message.reply(`Your current level is ${row.level} and you have ${row.points}${curren}!`);
      if (message.author.id === config.perUser.Tony3492) {
        message.reply("Has earned an achievement for being the first user to hit Level 2!")
      }
    });
  } else

  if (message.content.startsWith(prefix + "points")) {
    sql.get(`SELECT * FROM scores WHERE userId ="${message.author.id}"`).then(row => {
      if (!row) return message.reply("sadly you do not have any " + curren + " yet!");
      message.reply(`you currently have ${row.points}${curren}!`);
    });
  } else

  if (message.content.startsWith(prefix + "cheat") && message.member.roles.has(config.role.alaska_specialdev)) {
    sql.get(`SELECT * FROM scores WHERE userId ="${message.author.id}"`).then(row => {
      if (!row) {
        sql.run("INSERT INTO scores (userId, points, level) VALUES (?, ?, ?)", [message.author.id, 1, 0]);
      } else {
        let curLevel = Math.floor(0.1 * Math.sqrt(row.points + 100));
        if (curLevel > row.level) {
          row.level = curLevel;
          sql.run(`UPDATE scores SET points = ${row.points + 100}, level = ${row.level} WHERE userId = ${message.author.id}`);
          message.reply(`You've leveled up to level **${curLevel}**! Ain't that dandy?`);
        }
        sql.run(`UPDATE scores SET points = ${row.points + 100} WHERE userId = ${message.author.id}`);
      }
    }).catch(() => {
      console.error;
      sql.run("CREATE TABLE IF NOT EXISTS scores (userId TEXT, points INTEGER, level INTEGER)").then(() => {
        sql.run("INSERT INTO scores (userId, points, level) VALUES (?, ?, ?)", [message.author.id, 1, 0]);
      });
    });
  } */















} else if (message.content.startsWith(prefix + "ping")) {
  if (message.guild.id === config.guild.ALASKA) {
    check_csd = message.member.roles.has(config.role.alaska_csd)
    check_dev = message.member.roles.has(config.role.alaska_botdev)
    if (!check_csd && !check_dev) { // if both return empty
      message.channel.send(forbidden + "This command is intended for CSD/Developers.")
      return;
    }
  }
  message.channel.send("Calculating!").then(m => m.edit({embed: {
    color: 0xA7A7A5,
    timestamp: new Date(),
    footer: {
      icon_url: client.user.avatarURL,
      text: "Server Time"
    },
    author: {
      name: client.user.username,
      icon_url: client.user.avatarURL
    },
    fields: [
      {
        name: ":satellite_orbital: Pong!",
        value: "```markdown\n[!]: Round Trip```",
        inline: true
      },
      {
        name: ":satellite: __Latency__",
        value: "```\n" + (m.createdTimestamp - message.createdTimestamp) + "ms.```",
        inline: true
      }
    ]
  }}))


















} else if (message.content.startsWith(prefix + "ipstats")) {
  if (message.guild.id === config.guild.ALASKA) {
    if (!message.member.roles.has(config.role.alaska_csd)) {
      message.channel.send(forbidden + "This command is intended for CSD.")
      return;
    }
  } else if (message.guild.id === config.guild.DAVNET) {
    if (!message.member.roles.has(config.role.cyberID)) {
      message.channel.send(forbidden)
      return;
    }
  } else { // Safetynet
    message.channel.send(forbidden)
    return;
  }
  exec("/root/NC/utils/NorthStar/ipsabre.sh",
    function(error, stdout, stderr) {
      message.channel.send({embed: {
        color: 0xFF3D00,
        timestamp: new Date(),
        footer: {
          icon_url: client.user.avatarURL,
          text: "Server Time"
        },
        author: {
          name: client.user.username,
          icon_url: client.user.avatarURL
        },
        fields: [
          {
            name: "STRATUS 1 FIREWALL.DNET.LAB",
            value: stdout
          }
        ]
      }})
    })
// ipsummary /////////////////////////////////////////////////////////////////
} else if (message.content.startsWith(prefix + "ipsummary")) {
  if (message.member.roles.has(config.role.cyberID)) {
    exec("/root/NC/utils/NorthStar/ipbot.sh");
    message.channel.send("An IP Summary has been recorded.");
  } else {
    message.channel.send(forbidden + message.author)
    return;
  }




} else if (message.content.startsWith(prefix + "xks")) {
    if (message.member.roles.has(config.role.cyberID) || message.member.roles.has(config.role.alaska_csd)) {
      const xksregex = message.content.split(/\s+/g);
      if (xksregex[1] !== undefined) {
        exec('/root/NC/utils/NorthStar/xks.sh ' + xksregex[1],
          function(error, stdout, stderr) {
            //let regex = xksregex[1]
            if (stdout === "true\n") {
              var regval = ":large_orange_diamond: String was FOUND!"
            } else if (stdout === "false\n") {
              var regval = ":large_blue_diamond: String was NOT FOUND!"
            }
            //console.log(regval, xksregex[1], stdout)
            const embed = new Discord.RichEmbed()
              .setTitle('XKeyScore Regex')
              .setAuthor('firewall.dnet.lab')
              .setColor('0xFF3D00')
              .setDescription('Searches local database for XKeyScore words.')
              .setFooter('Server Time')
              //.setImage('https://i.imgur.com/sUj5UBw.jpg')
              .setThumbnail('https://i.imgur.com/iE39JgF.png')
              .setTimestamp()
              .setURL('https://duckduckgo.com/?q=xkeyscore')
              .addField('Here is what the monkeys could dig up.', '\u200b')
              .addField(regval, '```' + xksregex[1] + '```')
              //.addField('\u200b', '\u200b')
              //.addfield('You searched for:', '```{regex}```')
              message.channel.send({ embed });
          })
      } else {
        message.channel.send(message.author + " A string is required.")
      }
    } else {
      message.channel.send(forbidden + message.author)
      return;
    }
  // ipkilled //////////////////////////////////////////////////////////////////
  } else if (message.content.startsWith(prefix + "ipkilled")) {
    if (message.member.roles.has(config.role.cyberID) || message.member.roles.has(config.role.alaska_csd)) {
      exec("/root/NC/utils/NorthStar/ipkilled.sh",
      function (error, stdout, stderr) {
        message.channel.send({embed: {
          color: 0xFF3D00,
          author: {
            name: client.user.username,
            icon_url: client.user.avatarURL
          },
          fields: [
            {
              name: "Terminated subnets blocked by System",
              value: '```' + stdout + '```'
            }
          ],
          timestamp: new Date(),
          footer: {
            icon_url: client.user.avatarURL,
            text: "STRATUS 1 FIREWALL.DNET.LAB, Server Time"
          }
        }})}) // Confusing As Hell! Thank god for Atom
    } else {
      message.channel.send(forbidden + message.author)
      return;
    }














} else if (message.content.startsWith(prefix + "wttr")){
  if (message.guild.id === config.guild.ALASKA && !message.member.roles.has(config.role.alaska_citizen)) {
    message.channel.send(forbidden)
    return;
  }
  const locale = message.content.split(/\s+/g);
  if (locale[1] !== undefined) {
    exec('/root/NC/utils/NorthStar/wttr.in.sh ' + locale[1],
    function(error, stdout, stderr) {
      message.channel.send({embed: {
        color: 0x1979FF,
        author: {
          name: client.user.username,
          icon_url: client.user.avatarURL
        },
        title: 'wttr.in - Console-Like Weather Data',
        url: 'http://wttr.in/',
        description: "You searched for: " + locale[1],
        fields: [{
          name: ':loudspeaker::satellite_orbital: Hows this?',
          value: '```' + stdout + '```'
        }]
      }})
    })
  } else {
    message.channel.send("Give me a city name, " + message.author + "!\nExample: Halifax,Nova")
    return;
  }






} else if (message.content.startsWith(prefix + "math")) {
  if (message.guild.id === config.guild.ALASKA && !message.member.roles.has(config.role.alaska_csd)) {
    message.channel.send(forbidden)
    return;
  }
  const matts = message.content.split(/\s+/g);
  // Math2 is required to remove special formatting
  // Let the math program handle all arguments
  exec('math2 ' + matts[1] + ' ' + matts[2],
    function (error, stdout, stderr) { // May change to spam channel
      message.channel.send({embed: {
        color: 0xFFFF00,
        author: {
          name: client.user.username,
          icon_url: client.user.avatarURL
        },
        fields: [
          {
            name: "Output",
            value: '```' + stdout + '```'
          },
          {
            name: "Errors",
            value: '```' + stderr + '```'
          }
        ],
        timestamp: new Date(),
        footer: {
          icon_url: client.user.avatarURL,
          text: 'Mathematics Program, Server Time'
        }
      }})
  })



// Embed Test 1
client.on("message", (message) => {
  if (message.content.startsWith(prefix + "testembed1")) {
// message.channel.send("Test!");
message.channel.send({embed: {
  color: 3447003,
  author: {
    name: client.user.username,
    icon_url: client.user.avatarURL
  },
  title: 'This is an embed',
  url: 'http://google.com',
  description: 'This is a test embed to showcase what they look like and what they can do.',
  fields: [
    {
      name: 'Fields',
      value: 'They can have different fields with small headlines.'
    },
    {
      name: 'Masked links',
      value: 'You can put [masked links](http://google.com) inside of rich embeds.'
    },
    {
      name: 'Markdown',
      value: 'You can put all the *usual* **__Markdown__** inside of them.'
    }
  ],
  timestamp: new Date(),
  footer: {
    icon_url: client.user.avatarURL,
    text: 'Example'
  }
}});
  }
});


client.on("message", (message) => {
  if (message.content.startsWith(prefix + "embedtest2")) {
//    config.v = "0.1.7"
//    message.channel.send("Version " + config.v);
const embed = new Discord.RichEmbed()
  .setTitle('Very Nice Title')
  .setAuthor('Author Name', 'https://goo.gl/rHndF5')
  /*
   * Alternatively, use '#00AE86', [0, 174, 134] or an integer number.
   */
  .setColor(0x00AE86)
  .setDescription('The text of the body, essentially')
  .setFooter('Nice text at the bottom', 'https://goo.gl/hkFYh0')
  .setImage('https://goo.gl/D3uKk2')
  .setThumbnail('https://goo.gl/lhc6ke')
  /*
   * Takes a Date object, defaults to current date.
   */
  .setTimestamp()
  .setURL('https://discord.js.org/#/docs/main/indev/class/RichEmbed')
  .addField('Field Title', 'Field Value')
  /*
   * Inline fields may not display as inline if the thumbnail and/or image is too big.
   */
  .addField('Inline Field', 'Hmm 🤔', true)
  /*
   * Blank field, useful to create some space.
   */
  .addField('\u200b', '\u200b', true)
  .addField('Second (3rd place) Inline Field', 'I\'m in the ZOONE', true);

message.channel.send({ embed });
  }
});
